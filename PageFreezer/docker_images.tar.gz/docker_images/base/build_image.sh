cp ../../../requirements.txt .
docker build -t sm2base_service:1.0 .
rm -f requirements.txt
