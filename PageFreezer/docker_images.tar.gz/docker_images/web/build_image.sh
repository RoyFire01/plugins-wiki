#!/usr/bin/env bash

mkdir -p ./web

rsync --recursive ../../../../Frontend-2.0/ ./web/
