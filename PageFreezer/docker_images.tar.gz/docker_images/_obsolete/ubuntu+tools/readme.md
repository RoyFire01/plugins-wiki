### Dockerfile

Generic docker configuration file to build a basic docker instance with ssh, java7, supervisor, makes run SSH by default.