#!/usr/bin/env bash

rm -rf ./web_gums
