#!/usr/bin/env bash

mkdir -p ./web_gums

rsync --recursive ../../../../Global-User-Management-System/ ./web_gums/
