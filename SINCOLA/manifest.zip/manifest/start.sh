#! /bin/sh

mvn install:install-file -Dfile=/usr/src/app/sincolacoreutils/target/SinColaCoreUtils-1.6.0.jar -DgroupId=com.ve.sincola.utils -DartifactId=SinColaCoreUtils -Dversion=1.6.0 -Dpackaging=jar &&
mvn clean install

cp target/* /usr/local/tomcat/webapps/ 2&>/dev/null

/usr/local/tomcat/bin/catalina.sh run